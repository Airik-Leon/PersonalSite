
package com.dstsystems.services.subaccounting.dealeroptions.bean;


public class ExternalLedgerAccount{

    private    String defaultErrorAccount;
    private    String extlLedgerAccountNumber;
    private    String extlLedgerAccountName;

    public  String  getDefaultErrorAccount(){
        return this.defaultErrorAccount;
    }

    public void setDefaultErrorAccount( String  defaultErrorAccount){
        this.defaultErrorAccount = defaultErrorAccount;
    }
    public  String  getExtlLedgerAccountNumber(){
        return this.extlLedgerAccountNumber;
    }

    public void setExtlLedgerAccountNumber( String  extlLedgerAccountNumber){
        this.extlLedgerAccountNumber = extlLedgerAccountNumber;
    }
    public  String  getExtlLedgerAccountName(){
        return this.extlLedgerAccountName;
    }

    public void setExtlLedgerAccountName( String  extlLedgerAccountName){
        this.extlLedgerAccountName = extlLedgerAccountName;
    }

    @Override
    public String toString(){
        return new StringBuilder()
            .append("ExternalLedgerAccount}=[")
            .append("\ndefaultErrorAccount=")
            .append(this.defaultErrorAccount)
            .append("\nextlLedgerAccountNumber=")
            .append(this.extlLedgerAccountNumber)
            .append("\nextlLedgerAccountName=")
            .append(this.extlLedgerAccountName)
            .append("]").toString();
    }
}
