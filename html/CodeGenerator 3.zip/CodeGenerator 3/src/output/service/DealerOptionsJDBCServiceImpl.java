
package com.dstsystems.services.subaccounting.dealeroptions.service.dao;


@RequestScope
@Service(DealerOptionsConstants.DAO.DealerOptions_SERVICE_JDBC)
public class DealerOptionsJDBCDAOImpl implements IDealerOptionsService{

    @Autowired
    @Resource(name=SubaccountingServices.BeanName.BEAN_VALIDATOR)
    private DefaultBeanValidator validtor;


}
