
package com.dstsystems.services.subaccounting.dealeroptions.utils;

public class DealerOptionsConstants{

    public static class Service{
    public static final String DealerOptions_SERVICE_STORED_PROCEDURE = SubaccountingServices.NAME_SPACE + DealerOptionsService.V1;
    public static final String DealerOptions_SERVICE_JDBC = SubaccountingServices.NAME_SPACE + DealerOptionsService.V2;
    }

    public static class DAO{
    public static final String DealerOptions_DAO_STORED_PROCEDURE = SubaccountingServices.NAME_SPACE + DealerOptionsDAO.V1;
    public static final String DealerOptions_DAO_JDBC = SubaccountingServices.NAME_SPACE + DealerOptionsDAO.V2;
    }

}
