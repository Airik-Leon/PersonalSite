
package com.dstsystems.services.subaccounting.dealeroptions.bean;


public class DealerOptionsBean extends BslBaseBean{

    @Size(max=7)
    private    String fundSponsorId;
    private    String operatorId;
    private    String financialInstitutionid;

    public  String  getFundSponsorId(){
        return this.fundSponsorId;
    }

    public void setFundSponsorId( String  fundSponsorId){
        this.fundSponsorId = fundSponsorId;
    }
    public  String  getOperatorId(){
        return this.operatorId;
    }

    public void setOperatorId( String  operatorId){
        this.operatorId = operatorId;
    }
    public  String  getFinancialInstitutionid(){
        return this.financialInstitutionid;
    }

    public void setFinancialInstitutionid( String  financialInstitutionid){
        this.financialInstitutionid = financialInstitutionid;
    }

    @Override
    public String toString(){
        return new StringBuilder()
            .append("DealerOptionsBean}=[")
            .append("\nfundSponsorId=")
            .append(this.fundSponsorId)
            .append("\noperatorId=")
            .append(this.operatorId)
            .append("\nfinancialInstitutionid=")
            .append(this.financialInstitutionid)
            .append("]").toString();
    }
}
