const velocity = require('velocity.java');
const sanitizer = require('./Sanitizer.js')
const fs = require('fs');
module.exports = {
    init: json => {
        sanitizer.sanitizeGlobal(json);
    },
    generateBeans: json => {
        json.beans.forEach(bean => {
            sanitizer.sanitizeBean(bean);
            sanitizer.sanitizeFields(bean.fields);
            module.exports.render('Bean.vm', {global:json, bean: bean}, './resource/bean/', './output/bean/'+ bean.className + '.java');
        });
    },
    generateEntities: json => {
        json.entities.forEach(entity => {
            sanitizer.sanitizeBean(entity);
            sanitizer.sanitizeFields(entity.fields);
            module.exports.render('Entity.vm', {global:json, entity: entity}, './resource/bean/', './output/bean/'+ entity.className + '.java');
        });
    },
    generateDAO: json => {
        json.daos.forEach(dao => {
            module.exports.render('DAO.vm', { global: json, dao: dao }, './resource/service/dao/', './output/service/dao/' + json.baseName + dao.type + 'DAOImpl' + '.java');
        });
    },
    generateInterfaces: json => {
        json.interfaces.forEach(interface => {
            module.exports.render('Interface.vm', { global: json, daos: json.daos, interface:interface}, './resource/service/', './output/service/' + 'I' + json.baseName + interface.type + '.java');
        })
    },
    generateService: json => {
        json.services.forEach(service => {
            module.exports.render('Service.vm', { global: json, daos: json.daos, service:service}, './resource/service/', './output/service/' + json.baseName + service.type + 'ServiceImpl' + '.java');
        });
    },
    generateConstants: json => {
            module.exports.render('Constants.vm', { global: json, daos: json.daos, services: json.services }, './resource/utils/', './output/utils/' + json.baseName + 'Constants' + '.java');
    },
    generateController: json => {
        module.exports.render('Controller.vm', { global: json, daos: json.daos, services: json.services, controller:json.controller }, './resource/', './output/' + json.baseName + 'Controller' + '.java');
    },
    render: function (template, data, path, outputPath) {

        velocity.renderOnce(template, data, path, (err, file) =>{
            if (err) {
                console.error(err);
                return;
            }
            module.exports.saveFile(file.toString(), outputPath);
        });

    },

    saveFile: function (file, outputPath) {
        fs.writeFile(outputPath, file, (err) => {
            if (err) throw err;
            console.log(' written -> ' + outputPath);
        });
    }
}