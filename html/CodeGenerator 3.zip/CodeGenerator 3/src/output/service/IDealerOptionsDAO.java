
package com.dstsystems.services.subaccounting.dealeroptions.service;


public interface IDealerOptionsDAO{
    public DealerOptionsBean  index(DealerOptionsBean  bean);
    public DealerOptionsBean  update(DealerOptionsBean  bean);
}
