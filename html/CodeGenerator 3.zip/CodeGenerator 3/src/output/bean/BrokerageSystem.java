
package com.dstsystems.services.subaccounting.dealeroptions.bean;


public class BrokerageSystem{

    private    String brokerageSystemId;
    private    String brokerageSystemLongName;
    private    String brokerageSystemAbbrName;

    public  String  getBrokerageSystemId(){
        return this.brokerageSystemId;
    }

    public void setBrokerageSystemId( String  brokerageSystemId){
        this.brokerageSystemId = brokerageSystemId;
    }
    public  String  getBrokerageSystemLongName(){
        return this.brokerageSystemLongName;
    }

    public void setBrokerageSystemLongName( String  brokerageSystemLongName){
        this.brokerageSystemLongName = brokerageSystemLongName;
    }
    public  String  getBrokerageSystemAbbrName(){
        return this.brokerageSystemAbbrName;
    }

    public void setBrokerageSystemAbbrName( String  brokerageSystemAbbrName){
        this.brokerageSystemAbbrName = brokerageSystemAbbrName;
    }

    @Override
    public String toString(){
        return new StringBuilder()
            .append("BrokerageSystem}=[")
            .append("\nbrokerageSystemId=")
            .append(this.brokerageSystemId)
            .append("\nbrokerageSystemLongName=")
            .append(this.brokerageSystemLongName)
            .append("\nbrokerageSystemAbbrName=")
            .append(this.brokerageSystemAbbrName)
            .append("]").toString();
    }
}
