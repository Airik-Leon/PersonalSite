
package com.dstsystems.services.subaccounting.dealeroptions.service.dao;


@RequestScope
@Service(DealerOptionsConstants.DAO.DealerOptions_SERVICE_STORED_PROCEDURE)
public class DealerOptionsStoredProcedureDAOImpl implements IDealerOptionsService{

    @Autowired
    @Resource(name=SubaccountingServices.BeanName.BEAN_VALIDATOR)
    private DefaultBeanValidator validtor;

    @Autowired
    @Resource(name=DealerOptionsConstants.DAO.STORED_PROCEDURE);
    private DealerOptionsDAO dao;
    
    @Override
    public ServiceBean index(ServiceBean serviceBean){
        DealerOptionsBean bean = (DealerOptionsBean) serviceBean.get(DealerOptionsBean.class);
        validator.validate(bean);

        if(!bean.hasErrors){
            dao.index(bean);
        }

        serviceBean.put(DealerOptionsBean.class, bean);
        return serviceBean;
    }
    
    @Override
    public ServiceBean update(ServiceBean serviceBean){
        DealerOptionsBean bean = (DealerOptionsBean) serviceBean.get(DealerOptionsBean.class);
        validator.validate(bean);

        if(!bean.hasErrors){
            dao.update(bean);
        }

        serviceBean.put(DealerOptionsBean.class, bean);
        return serviceBean;
    }
    

}
