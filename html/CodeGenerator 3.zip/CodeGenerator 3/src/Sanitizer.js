module.exports = {

    sanitizeStatic: function (static) {
        return static ? "static" : "";
    },
    sanitizeFinal: function (final) {
        return final ? "final" : "";
    },
    sanitizeCollection: function (collection) {
        return collection ? collection : "";
    },
    sanitizeAccess: function (access) {
        return access ? access : "private";
    },
    sanitizeAnnotations: function (annotations) {
        return annotations ? annotations : [];
    },
    sanitizeFields: function (fields) {
        fields.forEach(field => {
            field.nameToFirstUpper = field.name.charAt(0).toUpperCase() + field.name.substring(1);
            field.static = module.exports.sanitizeStatic(field.static);
            field.final = module.exports.sanitizeFinal(field.final);
            field.collection = module.exports.sanitizeCollection(field.collection);
            field.access = module.exports.sanitizeAccess(field.access);
            field.annotations = module.exports.sanitizeAnnotations(field.annotations);
        });
    },
    sanitizeBean: bean => {
        bean.fields = bean.fields ? bean.fields : [];
    },
    sanitizeGlobal: function (global) {
        global.entities = global.entities ? global.entities : [];
        global.beans = global.beans ? global.beans : [];
        global.baseNameToLowercase = global.baseName.toLowerCase();
    }
}