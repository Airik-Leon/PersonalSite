const generator = require('./codegenerator.js')
const fs = require('fs');

const main = function () {
    var json = undefined;
    fs.readFile("./input.json", (err, data) => {
        json = JSON.parse(data);
        console.log('\n\nStarting new Project: ' + json.baseName);
        console.log('Working smart not hard, eh?')

        generator.init(json);
        generator.generateBeans(json);
        generator.generateEntities(json);
        generator.generateDAO(json);
        generator.generateConstants(json);
        generator.generateService(json);
        generator.generateInterfaces(json);
        generator.generateController(json);
    });
}
//Autoload
main();