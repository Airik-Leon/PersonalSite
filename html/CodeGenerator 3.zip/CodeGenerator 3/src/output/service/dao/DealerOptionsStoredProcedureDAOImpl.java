
package com.dstsystems.services.subaccounting.dealeroptions.service.dao;

@Repository(DealerOptionsConstants.DAO.DealerOptions_DAO_STORED_PROCEDURE)
public class DealerOptionsStoredProcedureDAOImpl extends IDealerOptionsDAO{

    private static final String STORED_PROCEDURE_SP00473 = SP00473;
    private static final String STORED_PROCEDURE_SP00482 = SP00482;

    @Override
    public DealerOptionsBean index(DealerOptionsBean bean){
        new StoredProcedureProcessor().Builder()
            .setBuilderBean(bean)
            .setBuilderRequestDTO(new DealerOptionsSpRequestDTO(bean))
            .setBuilderResponseClassType(DealerOptionsSpResponseDTO.class)
            .setBuilderStoredProcedureName(STORED_PROCEDURE_SP00473)
            .build()
            .process();
        return bean;
    }
    
    @Override
    public DealerOptionsBean update(DealerOptionsBean bean){
        new StoredProcedureProcessor().Builder()
            .setBuilderBean(bean)
            .setBuilderRequestDTO(new DealerOptionsSpRequestDTO(bean))
            .setBuilderResponseClassType(DealerOptionsSpResponseDTO.class)
            .setBuilderStoredProcedureName(STORED_PROCEDURE_SP00482)
            .build()
            .process();
        return bean;
    }
    

}
