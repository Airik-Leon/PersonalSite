
package com.dstsystems.services.subaccounting.dealeroptions.service;


public interface IDealerOptionsService{
    public ServiceBean  index(ServiceBean serviceBean);
    public ServiceBean  update(ServiceBean serviceBean);
}
