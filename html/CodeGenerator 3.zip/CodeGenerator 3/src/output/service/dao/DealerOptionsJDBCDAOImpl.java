
package com.dstsystems.services.subaccounting.dealeroptions.service.dao;

@Repository(DealerOptionsConstants.DAO.DealerOptions_DAO_JDBC)
public class DealerOptionsJDBCDAOImpl extends IDealerOptionsDAO{


}
