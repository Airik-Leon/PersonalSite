

package com.dstsystems.services.subaccounting.dealeroptions;


@RestController
public class DealerOptionsController extends SubaccountingServicesBaseController{

    @Autowired
    @Resource(name=SubaccountingServiceBean.SUBACCOUNTING_SERVICEBEAN)
    private SubaccountingServiceBean serviceBean;

    @Autowired
    private BslContextHeader util;

    @GetMapping(path="/DealerOptions", produces = MediaType.APPLICATION_JSON)
    public ResponseEntity<?> index( String fundSponsorId, String financialInstitutionId, String fundGroupNumber, HttpServletResponse response){
    DealerOptionsBean bean = new DealerOptionsBean();
    
    }

}
